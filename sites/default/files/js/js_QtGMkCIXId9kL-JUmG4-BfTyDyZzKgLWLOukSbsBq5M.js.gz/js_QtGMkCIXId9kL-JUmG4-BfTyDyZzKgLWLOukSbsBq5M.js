"use strict";
document.addEventListener('DOMContentLoaded', function (event) {
    console.log('DOM fully loaded and parsed');
    //console.log(drupalSettings);
});
window.addEventListener('load', function() {
    console.log('window and all contents loaded');
    //console.log(drupalSettings);
});
;
